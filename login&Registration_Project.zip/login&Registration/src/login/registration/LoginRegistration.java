
package login.registration;

import coreStructure.Login;

public class LoginRegistration {

    public static void main(String[] args) {
        Login lg = new Login();
        lg.setVisible(true);
    }
    
}
